# This is the Eventsy Website

## This folder is a in class project.

This is the professor file and e will be uplating it weekly.

This is the url for the eventsy website:

https://satejchm.github.io/215repos/eventsy-hero/
